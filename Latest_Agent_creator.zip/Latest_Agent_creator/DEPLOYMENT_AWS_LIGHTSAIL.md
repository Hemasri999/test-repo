# 🚀 AWS Lightsail Deployment Guide

Deploy your AI Agent Creator to AWS Lightsail in ~15 minutes.

## 📋 Prerequisites

- AWS Account ([aws.amazon.com](https://aws.amazon.com))
- Domain name (optional, but recommended)
- Anthropic API key

## 💰 Cost Estimate

**Recommended Plan: $5/month**
- 1 GB RAM
- 1 vCPU
- 40 GB SSD
- 2 TB transfer

Perfect for small to medium usage.

---

## 🎯 Step-by-Step Deployment

### **Step 1: Create Lightsail Instance**

1. **Go to AWS Lightsail Console**
   - Visit: https://lightsail.aws.amazon.com
   - Sign in to your AWS account

2. **Create Instance**
   - Click **"Create instance"**
   - **Region:** Choose closest to your users
   - **Platform:** Linux/Unix
   - **Blueprint:** Node.js (or OS Only → Ubuntu 22.04)

3. **Choose Instance Plan**
   - Select **$5/month plan** (1GB RAM)
   - Name: `agent-creator`

4. **Create Instance**
   - Click **"Create instance"**
   - Wait 2-3 minutes for provisioning

---

### **Step 2: Connect to Your Instance**

**Option A: Browser SSH (Easy)**
1. Click on your instance name
2. Click **"Connect using SSH"** button
3. Browser terminal opens

**Option B: SSH Key (Advanced)**
```bash
ssh -i LightsailDefaultKey.pem ubuntu@YOUR_INSTANCE_IP
```

---

### **Step 3: Install Dependencies**

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Node.js 18.x
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs

# Install git
sudo apt install -y git

# Install PM2 (process manager)
sudo npm install -g pm2

# Install nginx (web server)
sudo apt install -y nginx

# Verify installations
node --version  # Should show v18.x
npm --version   # Should show 9.x or higher
```

---

### **Step 4: Clone Your Repository**

**Option A: From GitHub**
```bash
cd /home/ubuntu
git clone https://github.com/YOUR_USERNAME/agent-creator.git
cd agent-creator
```

**Option B: Upload Files Manually**
```bash
# On your local machine
scp -r C:\Users\sunil\Documents\agent-creator ubuntu@YOUR_IP:/home/ubuntu/

# Then on server
cd /home/ubuntu/agent-creator
```

---

### **Step 5: Configure Environment Variables**

```bash
# Create .env file
nano .env
```

Add this content (replace with your actual keys):
```env
# Server Configuration
PORT=3001
NODE_ENV=production

# API Keys (REQUIRED - Replace with your keys!)
ANTHROPIC_API_KEY=your_anthropic_key_here

# Optional Tool API Keys
SERPAPI_KEY=your_serpapi_key_here
OPENWEATHER_KEY=your_openweather_key_here
```

**Save:** Press `Ctrl+X`, then `Y`, then `Enter`

---

### **Step 6: Update Server Configuration**

Create a production-ready server file:

```bash
nano server.js
```

Update to read from environment variables:

```javascript
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const fetch = require('node-fetch');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(cors());
app.use(express.json());

// Serve static files from React build
app.use(express.static(path.join(__dirname, 'build')));

// Load API keys from environment
let externalApiKeys = {
  serpapi: process.env.SERPAPI_KEY || '',
  openweather: process.env.OPENWEATHER_KEY || ''
};

// Endpoint to save external API keys
app.post('/api/external-keys', (req, res) => {
  const { serpapi, openweather } = req.body;
  if (serpapi) externalApiKeys.serpapi = serpapi;
  if (openweather) externalApiKeys.openweather = openweather;
  res.json({ success: true });
});

// Tool execution endpoint
app.post('/api/execute-tool', async (req, res) => {
  try {
    const { toolName, toolInput } = req.body;

    switch (toolName) {
      case 'web_search':
        if (externalApiKeys.serpapi) {
          try {
            const response = await fetch(
              `https://serpapi.com/search.json?q=${encodeURIComponent(toolInput.query)}&api_key=${externalApiKeys.serpapi}`
            );
            const data = await response.json();

            if (data.organic_results && data.organic_results.length > 0) {
              const results = data.organic_results.slice(0, 5).map((r, i) =>
                `${i + 1}. ${r.title}\n${r.snippet}\nSource: ${r.link}`
              ).join('\n\n');
              return res.json({ result: `Search results for "${toolInput.query}":\n\n${results}` });
            }
          } catch (e) {
            console.error('SerpAPI error:', e);
          }
        }

        try {
          const response = await fetch(
            `https://api.duckduckgo.com/?q=${encodeURIComponent(toolInput.query)}&format=json&no_html=1&skip_disambig=1`
          );
          const data = await response.json();

          if (data.Abstract) {
            return res.json({ result: `Search result for "${toolInput.query}":\n\n${data.Abstract}\n\nSource: ${data.AbstractURL || 'DuckDuckGo'}` });
          } else if (data.RelatedTopics && data.RelatedTopics.length > 0) {
            const topics = data.RelatedTopics.slice(0, 3).map((t, i) =>
              t.Text ? `${i + 1}. ${t.Text}` : ''
            ).filter(Boolean).join('\n');
            return res.json({ result: `Related information for "${toolInput.query}":\n\n${topics}` });
          }
        } catch (e) {
          console.error('DuckDuckGo error:', e);
        }

        return res.json({ result: 'Unable to search. Please try a different query.' });

      case 'calculator':
        try {
          const sanitized = toolInput.expression
            .replace(/[^0-9+\-*/().\s]/g, '')
            .replace(/\^/g, '**');

          const mathFuncs = {
            sqrt: Math.sqrt,
            sin: Math.sin,
            cos: Math.cos,
            tan: Math.tan,
            abs: Math.abs,
            pow: Math.pow,
            log: Math.log,
            exp: Math.exp
          };

          let expression = sanitized;
          Object.keys(mathFuncs).forEach(func => {
            const regex = new RegExp(`\\b${func}\\b`, 'g');
            expression = expression.replace(regex, `Math.${func}`);
          });

          const result = Function(`"use strict"; return (${expression})`)();
          return res.json({ result: `Result: ${result}` });
        } catch (e) {
          return res.json({ result: `Error: Invalid mathematical expression - ${e.message}` });
        }

      case 'get_weather':
        if (!externalApiKeys.openweather) {
          return res.json({ result: 'Weather API key not configured.' });
        }

        try {
          const response = await fetch(
            `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(toolInput.location)}&appid=${externalApiKeys.openweather}&units=imperial`
          );

          if (!response.ok) {
            throw new Error('Weather API request failed');
          }

          const data = await response.json();

          return res.json({
            result: `Weather in ${data.name}, ${data.sys.country}:
Temperature: ${Math.round(data.main.temp)}°F (feels like ${Math.round(data.main.feels_like)}°F)
Conditions: ${data.weather[0].description}
Humidity: ${data.main.humidity}%
Wind Speed: ${Math.round(data.wind.speed)} mph`
          });
        } catch (e) {
          return res.json({ result: `Error getting weather data: ${e.message}` });
        }

      default:
        return res.json({ result: 'Tool not found' });
    }
  } catch (error) {
    console.error('Tool execution error:', error);
    res.status(500).json({ error: 'Tool execution failed', message: error.message });
  }
});

// Proxy endpoint for Anthropic API
app.post('/api/chat', async (req, res) => {
  try {
    const { messages, system, model, max_tokens, temperature, tools } = req.body;
    const apiKey = req.headers['x-api-key'] || process.env.ANTHROPIC_API_KEY;

    if (!apiKey) {
      return res.status(401).json({ error: 'API key is required' });
    }

    const requestBody = {
      model: model || 'claude-sonnet-4-5-20250929',
      system,
      messages,
      max_tokens: max_tokens || 1024,
      temperature: temperature || 1.0
    };

    if (tools && tools.length > 0) {
      requestBody.tools = tools;
    }

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify(requestBody)
    });

    const data = await response.json();

    if (!response.ok) {
      console.error('Anthropic API Error:', data);
      return res.status(response.status).json(data);
    }

    res.json(data);
  } catch (error) {
    console.error('Server error:', error);
    res.status(500).json({ error: 'Internal server error', message: error.message });
  }
});

// Serve React app for all other routes
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'build', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
  console.log(`Environment: ${process.env.NODE_ENV}`);
});
```

---

### **Step 7: Update Frontend Configuration**

Update `src/App.js` to use environment-based API URLs:

```bash
nano src/App.js
```

Find all instances of `http://localhost:3001` and replace with:
```javascript
const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:3001';

// Then use it like:
fetch(`${API_URL}/api/chat`, {
  // ...
})
```

Or create a `.env.production` file:
```bash
nano .env.production
```

Add:
```env
REACT_APP_API_URL=/
```

---

### **Step 8: Install Dependencies & Build**

```bash
# Install dependencies
npm install

# Install dotenv for environment variables
npm install dotenv

# Build React app for production
npm run build

# This creates a 'build' folder with optimized files
```

---

### **Step 9: Start Server with PM2**

```bash
# Start the server
pm2 start server.js --name agent-creator

# Save PM2 configuration
pm2 save

# Setup PM2 to start on system boot
pm2 startup
# Copy and run the command it outputs
```

**Verify it's running:**
```bash
pm2 status
pm2 logs agent-creator
```

---

### **Step 10: Configure Nginx**

```bash
# Create nginx configuration
sudo nano /etc/nginx/sites-available/agent-creator
```

Add this configuration:
```nginx
server {
    listen 80;
    server_name YOUR_DOMAIN.com www.YOUR_DOMAIN.com;

    # Redirect to add trailing slash
    location ~ ^/([^.]*[^/])$ {
        return 301 $scheme://$host$uri/;
    }

    # Serve static files
    location / {
        root /home/ubuntu/agent-creator/build;
        try_files $uri $uri/ /index.html;
        
        # Cache static assets
        location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg)$ {
            expires 1y;
            add_header Cache-Control "public, immutable";
        }
    }

    # Proxy API requests to Node.js
    location /api/ {
        proxy_pass http://localhost:3001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }

    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_types text/plain text/css text/xml text/javascript application/x-javascript application/xml+rss application/json;

    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header X-Content-Type-Options "nosniff" always;
}
```

**Enable the site:**
```bash
# Create symbolic link
sudo ln -s /etc/nginx/sites-available/agent-creator /etc/nginx/sites-enabled/

# Remove default site
sudo rm /etc/nginx/sites-enabled/default

# Test nginx configuration
sudo nginx -t

# Restart nginx
sudo systemctl restart nginx
```

---

### **Step 11: Configure Firewall**

```bash
# Open ports
sudo ufw allow 22      # SSH
sudo ufw allow 80      # HTTP
sudo ufw allow 443     # HTTPS (for later)
sudo ufw enable

# Verify
sudo ufw status
```

**Also in Lightsail Console:**
1. Go to your instance
2. Click **"Networking"** tab
3. Add firewall rules:
   - HTTP (80)
   - HTTPS (443)

---

### **Step 12: Setup Static IP (Important!)**

1. Go to Lightsail console
2. Click **"Networking"** tab
3. Click **"Create static IP"**
4. Attach to your instance
5. Note the IP address

---

### **Step 13: Configure Domain (Optional)**

**If you have a domain:**

1. **In Lightsail DNS:**
   - Click **"Networking"** → **"Create DNS zone"**
   - Add your domain
   - Create records:
     - `A` record: `@` → Your Static IP
     - `A` record: `www` → Your Static IP

2. **Update your domain registrar:**
   - Use Lightsail nameservers shown in DNS zone

**OR use your existing DNS provider:**
- Add `A` record pointing to your Lightsail static IP

---

### **Step 14: Setup SSL (HTTPS) with Let's Encrypt**

```bash
# Install Certbot
sudo apt install -y certbot python3-certbot-nginx

# Get SSL certificate (replace with your domain)
sudo certbot --nginx -d yourdomain.com -d www.yourdomain.com

# Follow the prompts
# Choose option 2 to redirect HTTP to HTTPS

# Test auto-renewal
sudo certbot renew --dry-run
```

**Certbot will automatically:**
- Get SSL certificate
- Update nginx configuration
- Setup auto-renewal

---

## 🎉 **Done! Your App is Live!**

Visit your domain or IP address:
- **With domain:** https://yourdomain.com
- **Without domain:** http://YOUR_STATIC_IP

---

## 🔧 Maintenance & Management

### **View Logs**
```bash
# PM2 logs
pm2 logs agent-creator

# Nginx logs
sudo tail -f /var/log/nginx/access.log
sudo tail -f /var/log/nginx/error.log
```

### **Restart App**
```bash
pm2 restart agent-creator
```

### **Update Code**
```bash
cd /home/ubuntu/agent-creator

# Pull latest changes
git pull

# Install new dependencies (if any)
npm install

# Rebuild React app
npm run build

# Restart server
pm2 restart agent-creator
```

### **Monitor Resources**
```bash
# CPU and memory usage
htop

# PM2 monitoring
pm2 monit
```

---

## 📊 Performance Optimization

### **Enable Compression**
Already configured in nginx (gzip)

### **Setup CDN (Optional)**
- Use CloudFront or Cloudflare
- Point to your Lightsail instance

### **Database (If needed later)**
```bash
# Install MongoDB
sudo apt install -y mongodb

# Or use AWS services:
# - RDS (MySQL/PostgreSQL)
# - DynamoDB
# - DocumentDB (MongoDB-compatible)
```

---

## 🔐 Security Best Practices

### **1. Keep System Updated**
```bash
# Run weekly
sudo apt update && sudo apt upgrade -y
```

### **2. Strong SSH**
```bash
# Disable password authentication
sudo nano /etc/ssh/sshd_config
# Set: PasswordAuthentication no
sudo systemctl restart sshd
```

### **3. Fail2Ban (Optional)**
```bash
sudo apt install -y fail2ban
sudo systemctl enable fail2ban
```

### **4. Regular Backups**
- Use Lightsail snapshots (Settings → Snapshots)
- Schedule automatic snapshots
- Keep 3-5 recent snapshots

---

## 💰 Cost Management

**Monthly costs:**
- Instance: $5/month
- Static IP: Free (if attached)
- Data transfer: 2TB included
- DNS: Free
- SSL: Free (Let's Encrypt)

**Total: ~$5/month** 🎉

---

## 🚨 Troubleshooting

### **App not loading**
```bash
# Check if server is running
pm2 status

# Check logs
pm2 logs agent-creator

# Check nginx
sudo systemctl status nginx
sudo nginx -t
```

### **502 Bad Gateway**
```bash
# Server probably crashed
pm2 restart agent-creator
pm2 logs agent-creator
```

### **Can't connect to instance**
- Check firewall rules in Lightsail console
- Verify UFW: `sudo ufw status`
- Check SSH key permissions

### **SSL issues**
```bash
# Renew certificate manually
sudo certbot renew

# Check certificate status
sudo certbot certificates
```

---

## 📈 Scaling Options

**When you outgrow $5 plan:**

1. **Upgrade Lightsail instance**
   - $10/month: 2GB RAM
   - $20/month: 4GB RAM

2. **Move to EC2 + Load Balancer**
   - For high traffic
   - Auto-scaling capabilities

3. **Separate Database**
   - AWS RDS for data persistence
   - DynamoDB for NoSQL

4. **Add Caching**
   - Redis/ElastiCache
   - CloudFront CDN

---

## 🎯 Quick Commands Reference

```bash
# Start app
pm2 start server.js --name agent-creator

# Stop app  
pm2 stop agent-creator

# Restart app
pm2 restart agent-creator

# View logs
pm2 logs agent-creator

# Monitor
pm2 monit

# Restart nginx
sudo systemctl restart nginx

# View nginx logs
sudo tail -f /var/log/nginx/error.log
```

---

## ✅ Deployment Checklist

- [ ] Create Lightsail instance
- [ ] Install Node.js, PM2, nginx
- [ ] Clone/upload code
- [ ] Create `.env` file with API keys
- [ ] Install dependencies (`npm install`)
- [ ] Build React app (`npm run build`)
- [ ] Start with PM2
- [ ] Configure nginx
- [ ] Setup firewall
- [ ] Create static IP
- [ ] Configure domain (optional)
- [ ] Setup SSL (optional)
- [ ] Test the app
- [ ] Setup monitoring
- [ ] Schedule backups

---

**🎊 Congratulations! Your AI Agent Creator is now live on AWS Lightsail!**

Need help? Check the [USER_GUIDE.md](USER_GUIDE.md) or open an issue.

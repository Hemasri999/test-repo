# 🤖 AI Agent Creator

Build, customize, and deploy intelligent AI agents powered by Claude Sonnet 4.5.

![Version](https://img.shields.io/badge/version-1.0.0-blue)
![React](https://img.shields.io/badge/React-19.2.0-61dafb)
![Claude](https://img.shields.io/badge/Claude-Sonnet%204.5-purple)

## ✨ Features

- 🎨 **Beautiful Modern UI** - Dark theme with glassmorphism effects
- 🤖 **Multiple AI Agents** - Create unlimited specialized agents
- 📚 **Knowledge Base** - Upload documents for context-aware responses
- 🔧 **Tool Integration** - Web Search, Calculator, Weather
- 💬 **Interactive Chat** - Real-time conversations with your agents
- 🔒 **Secure** - Backend proxy keeps API keys safe

## 🚀 Quick Start

### Prerequisites
- Node.js (v14 or higher)
- npm or yarn
- Anthropic API key

### Installation

1. **Clone the repository**
```bash
git clone <your-repo-url>
cd agent-creator
```

2. **Install dependencies**
```bash
npm install
```

3. **Start the backend server**
```bash
node server.js
```

4. **Start the frontend** (in a new terminal)
```bash
npm start
```

5. **Open your browser**
```
http://localhost:3000
```

6. **Add your API keys**
- Click "Claude API" and enter your Anthropic API key
- (Optional) Click "Tool APIs" to add SerpAPI and OpenWeather keys

## 📖 Documentation

See **[USER_GUIDE.md](USER_GUIDE.md)** for detailed instructions on:
- Creating and configuring agents
- Using tools and knowledge bases
- Best practices and tips
- Troubleshooting

## 🛠️ Tech Stack

**Frontend:**
- React 19.2.0
- Tailwind CSS 3
- Lucide React (icons)

**Backend:**
- Express.js
- Node.js
- Anthropic Claude API

**Tools & APIs:**
- SerpAPI (web search)
- OpenWeatherMap (weather)
- DuckDuckGo (fallback search)

## 🎯 Use Cases

- 📊 **Research Assistant** - Search and analyze information
- 💼 **Customer Support** - Answer questions from knowledge base
- 🧮 **Math Tutor** - Solve problems step-by-step
- 🌍 **Travel Helper** - Weather forecasts and recommendations
- 💻 **Coding Assistant** - Help with programming tasks

## 📁 Project Structure

```
agent-creator/
├── public/
├── src/
│   ├── App.js          # Main React component
│   ├── App.css         # Styles and animations
│   └── index.js        # React entry point
├── server.js           # Backend Express server
├── package.json        # Dependencies
├── USER_GUIDE.md       # Detailed user guide
└── README.md           # This file
```

## 🔧 Available Tools

### 🔍 Web Search
- Powered by SerpAPI (with DuckDuckGo fallback)
- Get real-time information from Google
- 100 free searches/month with SerpAPI

### 🧮 Calculator
- Evaluate mathematical expressions
- Supports functions: sqrt, sin, cos, tan, abs, pow, log, exp
- No API key required

### 🌤️ Weather
- Current weather conditions
- Temperature, humidity, wind speed
- Requires free OpenWeatherMap API key

## 🌟 Screenshots

### Dashboard
Modern dark interface with gradient effects

### Chat Interface
Real-time conversations with tool usage indicators

### Agent Creation
Easy-to-use form with document upload and tool selection

## 🔐 Security

- API keys stored securely on backend
- CORS protection
- No sensitive data in browser localStorage
- Backend proxy prevents key exposure

## 🚨 Troubleshooting

**Backend won't start:**
```bash
npm install express cors node-fetch@2
```

**Frontend compilation errors:**
```bash
npm install -D tailwindcss@3 postcss autoprefixer
```

**Port conflicts:**
- Backend: Change PORT in `server.js`
- Frontend: Set PORT environment variable

See [USER_GUIDE.md](USER_GUIDE.md) for more troubleshooting tips.

## 📝 Environment Variables

Create `.env` file (optional):
```env
PORT=3001
ANTHROPIC_API_KEY=your_key_here
SERPAPI_KEY=your_key_here
OPENWEATHER_KEY=your_key_here
```

## 🤝 Contributing

Contributions welcome! Please:
1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Open a Pull Request

## 📄 License

MIT License - See LICENSE file for details

## 🙏 Acknowledgments

- **Anthropic** - Claude AI
- **Tailwind CSS** - Styling framework
- **Lucide** - Icon library
- **SerpAPI** - Search functionality
- **OpenWeatherMap** - Weather data

## 📞 Support

For issues and questions:
- Open an issue on GitHub
- Check [USER_GUIDE.md](USER_GUIDE.md)
- Review troubleshooting section

## 🗺️ Roadmap

- [ ] User authentication
- [ ] Cloud deployment guide
- [ ] More tool integrations
- [ ] Agent templates library
- [ ] Export/import agents
- [ ] Multi-language support

---

**Built with ❤️ using Claude Sonnet 4.5**

Star ⭐ this repo if you find it useful!

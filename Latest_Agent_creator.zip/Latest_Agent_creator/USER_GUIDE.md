# 🤖 AI Agent Creator - User Guide

## 📋 Setup (One Time)

### **1. Start the App**
Open two terminal windows:

```bash
# Terminal 1 - Backend Server
node server.js

# Terminal 2 - Frontend (React App)
npm start
```

Your browser will open to `http://localhost:3000`

### **2. Add API Keys**

#### **Claude API (Required)**
1. Click **"Claude API"** button
2. Enter your Anthropic API key (get from [console.anthropic.com](https://console.anthropic.com))
3. Click **"Save & Continue"**

#### **Tool APIs (Optional)**
1. Click **"Tool APIs"** button
2. Add keys:
   - **SerpAPI:** Better web search results ([serpapi.com](https://serpapi.com) - 100 free searches/month)
   - **OpenWeather:** Weather tool ([openweathermap.org/api](https://openweathermap.org/api) - free tier available)
3. Click **"Save API Keys"**

---

## ✨ Creating Your First Agent

### **Basic Steps**

1. Click **"+ Create Agent"** button
2. Fill in the form:

#### **Agent Name**
```
Example: Customer Support Bot
```

#### **System Prompt (Instructions)**
```
Example: You are a helpful customer support assistant. 
Be friendly, professional, and provide clear solutions to customer problems.
```

#### **Knowledge Base (Optional)**
- Click to upload documents (`.txt`, `.md`, `.csv`, `.json`)
- Agent will use these as reference when answering

#### **Tools & Capabilities**
Click to enable tools your agent needs:
- 🔍 **Web Search** - Search the internet for current information
- 🧮 **Calculator** - Perform mathematical calculations  
- 🌤️ **Weather** - Get current weather information

#### **Advanced Settings**
- **Temperature:** 0.3 (Focused) ↔ 1.0 (Creative)
- **Max Tokens:** Controls response length (default: 1024)

3. Click **"🚀 Create Agent"**

---

## 💬 Chatting with Agents

### **Start a Conversation**
1. Click **"Chat"** button on any agent card
2. Type your message in the input box
3. Press **Enter** or click **Send** button

### **How Tools Work**
Agents automatically use tools when needed. You'll see:
1. Your message (blue bubble)
2. **"🔧 Using tool: [tool_name]"** (yellow message)
3. Agent's response with results (gray bubble)

### **Example Queries**

**Web Search Agent:**
```
What's the current stock price of Tesla?
Who won the latest Super Bowl?
Latest news about AI
```

**Calculator Agent:**
```
Calculate 15% of 2,450
What is the square root of 144?
2,547 times 389
```

**Weather Agent:**
```
What's the weather in London?
Is it raining in Tokyo?
Temperature in New York City
```

---

## 🎨 Agent Templates

### **Research Assistant**
- **Tools:** Web Search
- **System Prompt:**
```
You are a research assistant. Search the web for current information 
and provide detailed, well-sourced answers. Always cite your sources.
```

### **Math Tutor**
- **Tools:** Calculator
- **System Prompt:**
```
You are a patient math tutor. Help students solve problems step-by-step. 
Show your work and explain each step clearly.
```

### **Travel Helper**
- **Tools:** Web Search, Weather
- **System Prompt:**
```
You help people plan trips. Provide weather forecasts, 
local attractions, and travel tips based on current information.
```

### **Customer Support Bot**
- **Tools:** None (uses knowledge base)
- **Documents:** Upload FAQs, policies, product guides
- **System Prompt:**
```
You are a customer support agent. Use the knowledge base to answer 
questions. Be friendly, professional, and helpful.
```

### **Coding Assistant**
- **Tools:** Web Search
- **System Prompt:**
```
You are an expert programmer. Help users with code, debug issues, 
and search for the latest programming best practices.
```

---

## 🔧 Managing Agents

### **Edit an Agent**
1. Click the **✏️ Edit** button on agent card
2. Modify settings
3. Click **"💾 Save Changes"**

### **Delete an Agent**
1. Click the **🗑️ Delete** button
2. Agent is permanently removed

### **Agent Cards Show:**
- 🤖 Agent name and description
- 📄 Number of documents attached
- 🔧 Number of tools enabled
- Action buttons (Chat, Edit, Delete)

---

## 💡 Best Practices

### **Writing Good System Prompts**
✅ **Do:**
- Be specific about personality and behavior
- Include tone guidelines (friendly, professional, casual)
- Define the agent's role clearly
- Mention when to use tools

❌ **Don't:**
- Make prompts too vague
- Give conflicting instructions
- Forget to mention important constraints

### **Using Documents**
✅ **Best formats:**
- `.txt` - Plain text documentation
- `.md` - Markdown formatted guides
- `.csv` - Data tables
- `.json` - Structured data

✅ **Good document examples:**
- Product manuals
- FAQ documents
- Company policies
- Knowledge bases
- Code documentation

### **Tool Selection**
Only enable tools your agent actually needs:
- **Web Search:** For current/real-time information
- **Calculator:** For mathematical operations
- **Weather:** For location-based forecasts

### **Temperature Settings**
- **0.0 - 0.3:** Focused, deterministic, factual (Good for: Support, Calculations)
- **0.4 - 0.7:** Balanced (Good for: General conversation)
- **0.8 - 1.0:** Creative, varied (Good for: Writing, Brainstorming)

---

## 🚨 Troubleshooting

### **"Could not connect to Claude API"**
**Causes:**
- Invalid API key
- Backend server not running
- No internet connection

**Solutions:**
1. Check your API key at [console.anthropic.com](https://console.anthropic.com)
2. Restart backend: `node server.js`
3. Re-enter API key via "Claude API" button

---

### **"Tool not working"**
**Causes:**
- Tool API keys not saved to backend
- Backend server restarted

**Solutions:**
1. Go back to agents list
2. Click "Tool APIs"
3. Re-enter your API keys
4. Click "Save API Keys" (sends to backend)

---

### **Web Search returns no results**
**Causes:**
- No SerpAPI key configured
- DuckDuckGo fallback has limited data

**Solutions:**
1. Add SerpAPI key ([serpapi.com](https://serpapi.com))
2. Try more general search queries
3. Check backend terminal for error messages

---

### **Backend server won't start**
**Causes:**
- Missing dependencies
- Port 3001 already in use

**Solutions:**
```bash
# Install dependencies
npm install express cors node-fetch@2

# Kill process using port 3001 (Windows)
netstat -ano | findstr :3001
taskkill /PID [PID_NUMBER] /F

# Kill process using port 3001 (Mac/Linux)
lsof -ti:3001 | xargs kill -9
```

---

## 📊 Understanding the Interface

### **Main Dashboard**
- **Header:** App title and navigation
- **Action Buttons:** Tool APIs, Claude API, Create Agent
- **Stats Bar:** Shows active agents count
- **Agent Grid:** All your created agents

### **Agent Card**
- **Title:** Agent name with gradient on hover
- **Description:** System prompt preview (3 lines)
- **Badges:** Document count, tool count
- **Actions:** Chat, Edit, Delete buttons

### **Chat Interface**
- **Header:** Agent name, model info, back button
- **Tool Badges:** Shows enabled tools
- **Messages:** User (blue), Assistant (gray), Tools (yellow)
- **Input:** Type messages, press Enter or click Send
- **Loading:** Animated dots while processing

---

## 🎯 Example Use Cases

### **Personal Assistant**
```
Agent: Daily Helper
Tools: Web Search, Weather, Calculator
Use: Check weather, news, calculations, research
```

### **Study Buddy**
```
Agent: Study Helper  
Tools: Web Search, Calculator
Documents: Upload textbooks, notes
Use: Answer questions, solve problems, research topics
```

### **Business Analyst**
```
Agent: Market Researcher
Tools: Web Search
Use: Stock prices, company info, market trends
```

### **Technical Support**
```
Agent: Tech Support Bot
Documents: Product manuals, troubleshooting guides
Use: Answer technical questions, help with issues
```

---

## 🔐 Security & Privacy

### **API Keys**
- ✅ Stored in backend server (not exposed in browser)
- ✅ Never committed to git (in `.gitignore`)
- ❌ Never share your API keys
- ❌ Never commit keys to public repositories

### **Data Storage**
- Agents saved in browser localStorage
- No data sent to external servers except:
  - Anthropic API (for Claude responses)
  - Tool APIs (SerpAPI, OpenWeather when used)

### **Best Practices**
1. Keep API keys secure
2. Use environment variables in production
3. Regularly rotate API keys
4. Monitor API usage on provider dashboards

---

## 🚀 Advanced Tips

### **Multi-Step Workflows**
Agents can use multiple tools in sequence:
```
You: "Search for Apple stock price and calculate 10% of it"
Agent: 
1. 🔧 Uses web_search
2. 🔧 Uses calculator  
3. Provides answer
```

### **Document Referencing**
When agents have documents, they automatically reference them:
```
You: "What's our return policy?"
Agent: [Reads uploaded policy.txt] 
       "According to our policy document..."
```

### **Custom Personalities**
Create specialized personalities:
```
Friendly: "You're enthusiastic and use emojis! 😊"
Professional: "You're formal and business-like."
Teacher: "You explain concepts simply with examples."
Expert: "You provide deep technical analysis."
```

---

## 📚 Additional Resources

### **Get API Keys**
- **Anthropic Claude:** [console.anthropic.com](https://console.anthropic.com)
- **SerpAPI:** [serpapi.com](https://serpapi.com)
- **OpenWeatherMap:** [openweathermap.org/api](https://openweathermap.org/api)

### **Learn More**
- **Claude Documentation:** [docs.anthropic.com](https://docs.anthropic.com)
- **Prompt Engineering:** [docs.anthropic.com/claude/docs/prompt-engineering](https://docs.anthropic.com/claude/docs/prompt-engineering)

---

## 🎉 Quick Reference

### **Keyboard Shortcuts**
- **Enter** - Send message
- **Esc** - Close dialogs

### **File Support**
- `.txt` - Text files
- `.md` - Markdown  
- `.csv` - CSV data
- `.json` - JSON data

### **Model Info**
- **Model:** Claude Sonnet 4.5
- **Provider:** Anthropic
- **Context:** Up to 200K tokens

---

## 🆘 Need Help?

**Common Commands:**
```bash
# Start backend
node server.js

# Start frontend
npm start

# Install dependencies
npm install

# Check if servers are running
# Backend: http://localhost:3001
# Frontend: http://localhost:3000
```

**Check Logs:**
- Backend errors: Terminal 1 (server.js)
- Frontend errors: Browser Console (F12)
- Network issues: Browser Network tab (F12)

---

**Happy Creating! 🎊**

Made with ❤️ using Claude Sonnet 4.5

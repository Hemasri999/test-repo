const express = require('express');
const cors = require('cors');
const https = require('https');
const fetch = require('node-fetch');

const app = express();
const PORT = 3001;

// Middleware
app.use(cors());
app.use(express.json());

// Store external API keys (in production, use environment variables)
let externalApiKeys = {
  serpapi: '',
  openweather: ''
};

// Endpoint to save external API keys
app.post('/api/external-keys', (req, res) => {
  const { serpapi, openweather } = req.body;
  if (serpapi) externalApiKeys.serpapi = serpapi;
  if (openweather) externalApiKeys.openweather = openweather;
  console.log('✅ External API keys updated');
  res.json({ success: true });
});

// Tool execution endpoint
app.post('/api/execute-tool', async (req, res) => {
  try {
    const { toolName, toolInput } = req.body;
    console.log(`🔧 Executing tool: ${toolName}`, toolInput);

    switch (toolName) {
      case 'web_search':
        // Use SerpAPI if key is available
        if (externalApiKeys.serpapi) {
          try {
            const response = await fetch(
              `https://serpapi.com/search.json?q=${encodeURIComponent(toolInput.query)}&api_key=${externalApiKeys.serpapi}`
            );
            const data = await response.json();

            if (data.organic_results && data.organic_results.length > 0) {
              const results = data.organic_results.slice(0, 5).map((r, i) =>
                `${i + 1}. ${r.title}\n${r.snippet}\nSource: ${r.link}`
              ).join('\n\n');
              return res.json({ result: `Search results for "${toolInput.query}":\n\n${results}` });
            }
          } catch (e) {
            console.error('SerpAPI error:', e);
          }
        }

        // Fallback: Use DuckDuckGo
        try {
          const response = await fetch(
            `https://api.duckduckgo.com/?q=${encodeURIComponent(toolInput.query)}&format=json&no_html=1&skip_disambig=1`
          );
          const data = await response.json();

          if (data.Abstract) {
            return res.json({ result: `Search result for "${toolInput.query}":\n\n${data.Abstract}\n\nSource: ${data.AbstractURL || 'DuckDuckGo'}` });
          } else if (data.RelatedTopics && data.RelatedTopics.length > 0) {
            const topics = data.RelatedTopics.slice(0, 3).map((t, i) =>
              t.Text ? `${i + 1}. ${t.Text}` : ''
            ).filter(Boolean).join('\n');
            return res.json({ result: `Related information for "${toolInput.query}":\n\n${topics}` });
          }
        } catch (e) {
          console.error('DuckDuckGo error:', e);
        }

        return res.json({ result: 'Unable to search. Please try a different query.' });

      case 'calculator':
        try {
          const sanitized = toolInput.expression
            .replace(/[^0-9+\-*/().\s]/g, '')
            .replace(/\^/g, '**');

          const mathFuncs = {
            sqrt: Math.sqrt,
            sin: Math.sin,
            cos: Math.cos,
            tan: Math.tan,
            abs: Math.abs,
            pow: Math.pow,
            log: Math.log,
            exp: Math.exp
          };

          let expression = sanitized;
          Object.keys(mathFuncs).forEach(func => {
            const regex = new RegExp(`\\b${func}\\b`, 'g');
            expression = expression.replace(regex, `Math.${func}`);
          });

          const result = Function(`"use strict"; return (${expression})`)();
          return res.json({ result: `Result: ${result}` });
        } catch (e) {
          return res.json({ result: `Error: Invalid mathematical expression - ${e.message}` });
        }

      case 'get_weather':
        if (!externalApiKeys.openweather) {
          return res.json({ result: 'Weather API key not configured. Please add an OpenWeatherMap API key in settings.' });
        }

        try {
          const response = await fetch(
            `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(toolInput.location)}&appid=${externalApiKeys.openweather}&units=imperial`
          );

          if (!response.ok) {
            throw new Error('Weather API request failed');
          }

          const data = await response.json();

          return res.json({
            result: `Weather in ${data.name}, ${data.sys.country}:
Temperature: ${Math.round(data.main.temp)}°F (feels like ${Math.round(data.main.feels_like)}°F)
Conditions: ${data.weather[0].description}
Humidity: ${data.main.humidity}%
Wind Speed: ${Math.round(data.wind.speed)} mph`
          });
        } catch (e) {
          return res.json({ result: `Error getting weather data: ${e.message}` });
        }

      default:
        return res.json({ result: 'Tool not found' });
    }
  } catch (error) {
    console.error('Tool execution error:', error);
    res.status(500).json({ error: 'Tool execution failed', message: error.message });
  }
});

// Proxy endpoint for Anthropic API
app.post('/api/chat', async (req, res) => {
  try {
    const { messages, system, model, max_tokens, temperature, tools } = req.body;
    const apiKey = req.headers['x-api-key'];

    if (!apiKey) {
      console.error('❌ API key missing');
      return res.status(401).json({ error: 'API key is required' });
    }

    const requestBody = {
      model: model || 'claude-sonnet-4-5-20250929',
      system,
      messages,
      max_tokens: max_tokens || 1024,
      temperature: temperature || 1.0
    };

    if (tools && tools.length > 0) {
      requestBody.tools = tools;
    }

    console.log('📡 Proxying request to Anthropic API...');
    console.log('Model:', requestBody.model);
    console.log('Messages:', messages.length);

    // Create HTTPS agent with proper configuration
    const httpsAgent = new https.Agent({
      rejectUnauthorized: true, // Changed to true for security (use false only for dev/testing)
      keepAlive: true
    });

    // FIXED: Pass the agent to fetch using node-fetch v2 syntax
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify(requestBody),
      agent: httpsAgent // ✅ NOW USING THE AGENT
    });

    const data = await response.json();

    if (!response.ok) {
      console.error('❌ Anthropic API Error:', response.status, data);
      return res.status(response.status).json(data);
    }

    console.log('✅ Anthropic API response received');
    res.json(data);
  } catch (error) {
    console.error('❌ Server error:', error.message);
    console.error('Stack:', error.stack);
    res.status(500).json({ 
      error: 'Internal server error', 
      message: error.message,
      details: error.code // Helpful for debugging network errors
    });
  }
});

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    timestamp: new Date().toISOString(),
    externalKeys: {
      serpapi: !!externalApiKeys.serpapi,
      openweather: !!externalApiKeys.openweather
    }
  });
});

app.listen(PORT, () => {
  console.log(`🚀 Backend server running on http://localhost:${PORT}`);
  console.log(`✅ Ready to proxy requests to Anthropic API`);
  console.log(`🔍 Health check: http://localhost:${PORT}/api/health`);
});

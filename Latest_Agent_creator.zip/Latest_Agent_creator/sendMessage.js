// IMPROVED sendMessage function for App_Agent.txt
// Replace the existing sendMessage function with this version

const sendMessage = async () => {
  if (!input.trim() || !apiKey) return;
  
  const userMessage = { role: 'user', content: input };
  const newMessages = [...messages, userMessage];
  setMessages(newMessages);
  setInput('');
  setIsLoading(true);
  
  try {
    // Build system prompt with documents
    let systemPrompt = selectedAgent.systemPrompt;
    
    if (selectedAgent.documents && selectedAgent.documents.length > 0) {
      systemPrompt += '\n\nYou have access to the following documents:\n\n';
      selectedAgent.documents.forEach((doc, idx) => {
        systemPrompt += `Document ${idx + 1}: ${doc.name}\n---\n${doc.content}\n---\n\n`;
      });
    }
    
    let conversationMessages = [...newMessages];
    let toolDefinitions = getToolDefinitions(selectedAgent.tools || []);
    let continueLoop = true;
    let displayMessages = [...newMessages];
    
    while (continueLoop) {
      const requestBody = {
        model: selectedAgent.model,
        system: systemPrompt,
        messages: conversationMessages,
        max_tokens: selectedAgent.maxTokens,
        temperature: selectedAgent.temperature
      };
      
      if (toolDefinitions.length > 0) {
        requestBody.tools = toolDefinitions;
      }
      
      console.log('🔄 Sending request to backend...', {
        endpoint: 'http://localhost:3001/api/chat',
        messageCount: conversationMessages.length,
        hasTools: toolDefinitions.length > 0
      });
      
      // ✅ CORRECT: Call backend proxy (not Anthropic directly)
      const response = await fetch('http://localhost:3001/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': apiKey
        },
        body: JSON.stringify(requestBody)
      });
      
      console.log('📥 Response status:', response.status, response.statusText);
      
      // Better error handling with detailed messages
      if (!response.ok) {
        let errorData;
        try {
          errorData = await response.json();
        } catch {
          errorData = { error: { message: `HTTP ${response.status}: ${response.statusText}` } };
        }
        
        console.error('❌ API Error:', errorData);
        
        // Throw detailed error
        throw new Error(JSON.stringify(errorData));
      }
      
      const data = await response.json();
      console.log('✅ Response received:', {
        stopReason: data.stop_reason,
        contentBlocks: data.content?.length
      });
      
      // Check if Claude wants to use a tool
      if (data.stop_reason === 'tool_use') {
        const toolUseBlock = data.content.find(block => block.type === 'tool_use');
        
        if (toolUseBlock) {
          console.log('🔧 Tool requested:', toolUseBlock.name, toolUseBlock.input);
          
          // Add tool use message to display
          displayMessages.push({
            role: 'assistant',
            content: `🔧 Using tool: ${toolUseBlock.name}`,
            isToolUse: true
          });
          setMessages([...displayMessages]);
          
          // Execute the tool
          const toolResult = await executeTool(toolUseBlock.name, toolUseBlock.input);
          console.log('✅ Tool result:', toolResult);
          
          // Add assistant message with tool use to conversation
          conversationMessages.push({
            role: 'assistant',
            content: data.content
          });
          
          // Add tool result to conversation
          conversationMessages.push({
            role: 'user',
            content: [
              {
                type: 'tool_result',
                tool_use_id: toolUseBlock.id,
                content: toolResult
              }
            ]
          });
          
          // Continue the loop to get final response
          continue;
        }
      }
      
      // Final response from Claude
      const textContent = data.content.find(block => block.type === 'text');
      if (textContent) {
        displayMessages.push({
          role: 'assistant',
          content: textContent.text
        });
      }
      
      continueLoop = false;
    }
    
    // Final state update with all messages
    setMessages(displayMessages);
    console.log('✅ Conversation complete');
    
  } catch (error) {
    console.error('❌ Full error:', error);
    
    let userFriendlyMessage = '❌ Error: Could not connect to Claude API.\n\n';
    
    // Parse error message
    let errorData;
    try {
      errorData = JSON.parse(error.message);
    } catch {
      errorData = { error: { message: error.message } };
    }
    
    const errorMessage = errorData.error?.message || error.message || 'Unknown error';
    
    // Provide specific guidance based on error type
    if (errorMessage.includes('401') || errorMessage.includes('authentication') || errorMessage.includes('invalid_api_key')) {
      userFriendlyMessage += '🔑 **Authentication Failed**\n\n';
      userFriendlyMessage += 'Your API key is invalid or expired.\n\n';
      userFriendlyMessage += '**Steps to fix:**\n';
      userFriendlyMessage += '1. Click "Back to Agents"\n';
      userFriendlyMessage += '2. Click "Claude API" button\n';
      userFriendlyMessage += '3. Enter a valid API key from console.anthropic.com\n';
      userFriendlyMessage += '4. Make sure it starts with "sk-ant-"';
    } else if (errorMessage.includes('429') || errorMessage.includes('rate_limit')) {
      userFriendlyMessage += '⏰ **Rate Limit Exceeded**\n\n';
      userFriendlyMessage += 'Too many requests in a short time.\n\n';
      userFriendlyMessage += 'Please wait a moment and try again.';
    } else if (errorMessage.includes('500') || errorMessage.includes('502') || errorMessage.includes('503')) {
      userFriendlyMessage += '🔧 **Server Error**\n\n';
      userFriendlyMessage += 'Anthropic\'s servers are temporarily unavailable.\n\n';
      userFriendlyMessage += 'This is usually brief - please try again in a few moments.';
    } else if (errorMessage.includes('ECONNREFUSED') || errorMessage.includes('fetch failed')) {
      userFriendlyMessage += '🔌 **Backend Connection Failed**\n\n';
      userFriendlyMessage += 'Cannot connect to the backend server.\n\n';
      userFriendlyMessage += '**Steps to fix:**\n';
      userFriendlyMessage += '1. Make sure backend is running: `node server_agent_FIXED.js`\n';
      userFriendlyMessage += '2. Check it\'s on port 3001\n';
      userFriendlyMessage += '3. Visit: http://localhost:3001/api/health';
    } else if (errorMessage.includes('CORS')) {
      userFriendlyMessage += '🌐 **CORS Error**\n\n';
      userFriendlyMessage += 'Cross-origin request blocked.\n\n';
      userFriendlyMessage += 'Make sure your backend has CORS enabled and is running.';
    } else {
      userFriendlyMessage += '❓ **Unexpected Error**\n\n';
      userFriendlyMessage += `Details: ${errorMessage}\n\n`;
      userFriendlyMessage += '**Troubleshooting:**\n';
      userFriendlyMessage += '1. Check browser console (F12) for details\n';
      userFriendlyMessage += '2. Check backend terminal for errors\n';
      userFriendlyMessage += '3. Verify API key is correct\n';
      userFriendlyMessage += '4. Ensure backend is running on port 3001';
    }
    
    setMessages([...newMessages, {
      role: 'assistant',
      content: userFriendlyMessage
    }]);
  } finally {
    setIsLoading(false);
  }
};

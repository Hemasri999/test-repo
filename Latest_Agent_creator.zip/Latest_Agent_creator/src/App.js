import React, { useState, useEffect, useRef } from 'react';
import { Plus, MessageSquare, Settings, Send, Trash2, Edit, Upload, File, X } from 'lucide-react';
import './App.css'; 
export default function AgentCreator() {
  const [agents, setAgents] = useState([]);
  const [selectedAgent, setSelectedAgent] = useState(null);
  const [view, setView] = useState('list'); // 'list', 'create', 'chat', 'edit'
  const [apiKey, setApiKey] = useState('');
  const [showApiKeyInput, setShowApiKeyInput] = useState(false);
  const [externalApiKeys, setExternalApiKeys] = useState({
    openweather: '',
    serpapi: ''
  });
  const [showExternalApiSettings, setShowExternalApiSettings] = useState(false);
  
  // Form state
  const [formData, setFormData] = useState({
    name: '',
    systemPrompt: '',
    temperature: 1.0,
    maxTokens: 1024,
    documents: [],
    tools: []
  });
  
  // Available tools
  const availableTools = [
    {
      id: 'web_search',
      name: 'Web Search',
      description: 'Search the internet for current information',
      icon: '🔍'
    },
    {
      id: 'calculator',
      name: 'Calculator',
      description: 'Perform mathematical calculations',
      icon: '🧮'
    },
    {
      id: 'get_weather',
      name: 'Weather',
      description: 'Get current weather information',
      icon: '🌤️'
    }
  ];
  
  // Chat state
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef(null);
  
  // Load agents and API key from localStorage
  useEffect(() => {
    const savedAgents = localStorage.getItem('agents');
    const savedApiKey = localStorage.getItem('anthropicApiKey');
    const savedExternalKeys = localStorage.getItem('externalApiKeys');
    
    if (savedAgents) setAgents(JSON.parse(savedAgents));
    if (savedApiKey) setApiKey(savedApiKey);
    else setShowApiKeyInput(true);
    if (savedExternalKeys) setExternalApiKeys(JSON.parse(savedExternalKeys));
  }, []);
  
  // Save agents to localStorage
  useEffect(() => {
    if (agents.length > 0) {
      localStorage.setItem('agents', JSON.stringify(agents));
    }
  }, [agents]);
  
  // Auto-scroll chat
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);
  
  const saveApiKey = () => {
    localStorage.setItem('anthropicApiKey', apiKey);
    setShowApiKeyInput(false);
  };
  
  const saveExternalApiKeys = async () => {
    localStorage.setItem('externalApiKeys', JSON.stringify(externalApiKeys));
    
    // Send to backend server
    try {
      await fetch('http://localhost:3001/api/external-keys', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(externalApiKeys)
      });
    } catch (error) {
      console.error('Error saving external API keys to backend:', error);
    }
    
    setShowExternalApiSettings(false);
  };
  
  const handleFileUpload = async (e) => {
    const files = Array.from(e.target.files);
    const newDocuments = [];
    
    for (const file of files) {
      const content = await readFileContent(file);
      newDocuments.push({
        id: Date.now() + Math.random(),
        name: file.name,
        type: file.type,
        size: file.size,
        content: content,
        uploadedAt: new Date().toISOString()
      });
    }
    
    setFormData({
      ...formData,
      documents: [...formData.documents, ...newDocuments]
    });
  };
  
  const readFileContent = (file) => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => resolve(e.target.result);
      reader.onerror = reject;
      reader.readAsText(file);
    });
  };
  
  const removeDocument = (docId) => {
    setFormData({
      ...formData,
      documents: formData.documents.filter(doc => doc.id !== docId)
    });
  };
  
  const toggleTool = (toolId) => {
    const currentTools = formData.tools || [];
    if (currentTools.includes(toolId)) {
      setFormData({
        ...formData,
        tools: currentTools.filter(t => t !== toolId)
      });
    } else {
      setFormData({
        ...formData,
        tools: [...currentTools, toolId]
      });
    }
  };
  
  const getToolDefinitions = (toolIds) => {
    const definitions = [];
    
    if (toolIds.includes('web_search')) {
      definitions.push({
        name: 'web_search',
        description: 'Search the internet for current information. Use this when you need up-to-date information.',
        input_schema: {
          type: 'object',
          properties: {
            query: {
              type: 'string',
              description: 'The search query'
            }
          },
          required: ['query']
        }
      });
    }
    
    if (toolIds.includes('calculator')) {
      definitions.push({
        name: 'calculator',
        description: 'Perform mathematical calculations. Input should be a mathematical expression.',
        input_schema: {
          type: 'object',
          properties: {
            expression: {
              type: 'string',
              description: 'Mathematical expression to evaluate (e.g., "2 + 2" or "sqrt(16)")'
            }
          },
          required: ['expression']
        }
      });
    }
    
    if (toolIds.includes('get_weather')) {
      definitions.push({
        name: 'get_weather',
        description: 'Get current weather information for a location.',
        input_schema: {
          type: 'object',
          properties: {
            location: {
              type: 'string',
              description: 'City name or location'
            }
          },
          required: ['location']
        }
      });
    }
    
    return definitions;
  };
  
  const executeTool = async (toolName, toolInput) => {
    try {
      // Call backend to execute the tool
      const response = await fetch('http://localhost:3001/api/execute-tool', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ toolName, toolInput })
      });
      
      if (!response.ok) {
        throw new Error('Tool execution failed');
      }
      
      const data = await response.json();
      return data.result;
    } catch (error) {
      console.error('Tool execution error:', error);
      return `Error executing tool: ${error.message}`;
    }
  };
  
  const createAgent = () => {
    const newAgent = {
      id: Date.now().toString(),
      name: formData.name,
      systemPrompt: formData.systemPrompt,
      temperature: formData.temperature,
      maxTokens: formData.maxTokens,
      documents: formData.documents,
      tools: formData.tools || [],
      model: 'claude-sonnet-4-5-20250929',
      createdAt: new Date().toISOString()
    };
    
    setAgents([...agents, newAgent]);
    setFormData({ name: '', systemPrompt: '', temperature: 1.0, maxTokens: 1024, documents: [], tools: [] });
    setView('list');
  };
  
  const updateAgent = () => {
    setAgents(agents.map(a => 
      a.id === selectedAgent.id 
        ? { ...a, ...formData }
        : a
    ));
    setView('list');
  };
  
  const deleteAgent = (id) => {
    setAgents(agents.filter(a => a.id !== id));
    if (selectedAgent?.id === id) {
      setSelectedAgent(null);
      setMessages([]);
    }
  };
  
  const startChat = (agent) => {
    setSelectedAgent(agent);
    setMessages([]);
    setView('chat');
  };
  
  const startEdit = (agent) => {
    setSelectedAgent(agent);
    setFormData({
      name: agent.name,
      systemPrompt: agent.systemPrompt,
      temperature: agent.temperature,
      maxTokens: agent.maxTokens,
      documents: agent.documents || [],
      tools: agent.tools || []
    });
    setView('edit');
  };
  
  const sendMessage = async () => {
    if (!input.trim() || !apiKey) return;
    
    const userMessage = { role: 'user', content: input };
    const newMessages = [...messages, userMessage];
    setMessages(newMessages);
    setInput('');
    setIsLoading(true);
    
    try {
      // Build system prompt with documents
      let systemPrompt = selectedAgent.systemPrompt;
      
      if (selectedAgent.documents && selectedAgent.documents.length > 0) {
        systemPrompt += '\n\nYou have access to the following documents:\n\n';
        selectedAgent.documents.forEach((doc, idx) => {
          systemPrompt += `Document ${idx + 1}: ${doc.name}\n---\n${doc.content}\n---\n\n`;
        });
      }
      
      let conversationMessages = [...newMessages];
      let toolDefinitions = getToolDefinitions(selectedAgent.tools || []);
      let continueLoop = true;
      let displayMessages = [...newMessages]; // Track messages for display
      
      while (continueLoop) {
        const requestBody = {
          model: selectedAgent.model,
          system: systemPrompt,
          messages: conversationMessages,
          max_tokens: selectedAgent.maxTokens,
          temperature: selectedAgent.temperature
        };
        
        if (toolDefinitions.length > 0) {
          requestBody.tools = toolDefinitions;
        }
        
        const response = await fetch('http://localhost:3001/api/chat', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-api-key': apiKey
          },
          body: JSON.stringify(requestBody)          
        });
        console.log("test",requestBody);
        
        if (!response.ok) {
          throw new Error('API request failed');
        }
        
        const data = await response.json();

        console.log("response",data);
        
        // Check if Claude wants to use a tool
        if (data.stop_reason === 'tool_use') {
          const toolUseBlock = data.content.find(block => block.type === 'tool_use');
          
          if (toolUseBlock) {
            // Add tool use message to display
            displayMessages.push({
              role: 'assistant',
              content: `🔧 Using tool: ${toolUseBlock.name}`,
              isToolUse: true
            });
            setMessages([...displayMessages]); // Update UI
            
            // Execute the tool
            const toolResult = await executeTool(toolUseBlock.name, toolUseBlock.input);
            
            // Add assistant message with tool use to conversation
            conversationMessages.push({
              role: 'assistant',
              content: data.content
            });
            
            // Add tool result to conversation
            conversationMessages.push({
              role: 'user',
              content: [
                {
                  type: 'tool_result',
                  tool_use_id: toolUseBlock.id,
                  content: toolResult
                }
              ]
            });
            
            // Continue the loop to get final response
            continue;
          }
        }
        
        // Final response from Claude
        const textContent = data.content.find(block => block.type === 'text');
        if (textContent) {
          displayMessages.push({
            role: 'assistant',
            content: textContent.text
          });
        }
        
        continueLoop = false;
      }
      
      // Final state update with all messages
      setMessages(displayMessages);
      
    } catch (error) {
      console.error('Error:', error);
      setMessages([...newMessages, {
        role: 'assistant',
        content: '❌ Error: Could not connect to Claude API. Please check your API key.'
      }]);
    } finally {
      setIsLoading(false);
    }
  };
  
  // API Key Setup View
  if (showApiKeyInput) {
    return (
      // <div className="min-h-screen bg-[#A9C9F4] flex items-center justify-center p-4">
      <div
      className="min-h-screen flex items-center justify-center p-4"
      style={{ background: 'linear-gradient(to right, #4A8FE2,rgb(245, 240, 190))' }}
    >
      {/* <img src="Cognizant Logo.png" alt="Logo" className="logo"/> */}
        <div className="relative bg-[#2F4F9D] rounded-2xl p-10 max-w-md w-full border border-blue-100/30">
        
          {/* <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-blue-500/10 via-purple-500/10 to-pink-500/10"></div> */}
          <div className="relative z-10">
            <div className="mb-6 text-center">
              <div className="inline-block p-4 bg-[#2F4F9D] rounded-full mb-4">
                <Settings size={32} className="text-white" />
              </div>
            </div>
            <h2 className="text-3xl font-bold text-white mb-2 text-center">Setup Required</h2>
            <p className="text-gray-300 mb-6 text-center">Enter your Anthropic API key to get started</p>
            <input
              type="password"
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              placeholder="sk-ant-..."
              className="w-full px-5 py-4 border-2 border-purple-500/30 bg-slate-800/50 text-white rounded-xl mb-6 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent placeholder-gray-500 backdrop-blur-sm"
            />
            <button
              onClick={saveApiKey}
              disabled={!apiKey}
              
className="w-full bg-[#6A8FD4] text-white py-4 rounded-xl hover:bg-[#2F4F9D] disabled:bg-gray-600 font-bold text-lg transition-all duration-300 transform hover:scale-105 disabled:transform-none disabled:cursor-not-allowed"
>

              Save & Continue →
            </button>
            <p className="text-sm text-gray-400 mt-6 text-center">
              Get your API key from{' '}
              <a href="https://console.anthropic.com" target="_blank" rel="noopener noreferrer" className="text-purple-400 hover:text-purple-300 hover:underline font-semibold">
                console.anthropic.com
              </a>
            </p>
          </div>
        </div>
      </div>
    );
  }
  
  // External API Keys Setup View
  if (showExternalApiSettings) {
    return (
      <div
      className="min-h-screen flex items-center justify-center p-4"
      style={{ background: 'linear-gradient(to right, #4A8FE2,rgb(245, 240, 190))' }}
    >
        <div className="relative bg-gradient-to-br from-slate-800/90 to-slate-900/90 rounded-2xl shadow-2xl p-10 max-w-2xl w-full border border-purple-500/30 backdrop-blur-sm">
          {/* <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-blue-500/5 via-purple-500/5 to-pink-500/5"></div> */}
          <div className="relative z-10">
            <h2 className="text-3xl font-bold text-white mb-3">Tool API Keys</h2>
            <p className="text-gray-300 mb-8">Configure API keys for tools to enable real-time data access.</p>
            
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-semibold text-gray-200 mb-3">
                  🌤️ OpenWeatherMap API Key (for Weather tool)
                </label>
                <input
                  type="password"
                  value={externalApiKeys.openweather}
                  onChange={(e) => setExternalApiKeys({...externalApiKeys, openweather: e.target.value})}
                  placeholder="Enter OpenWeatherMap API key"
                  className="w-full px-5 py-4 border-2 border-purple-500/30 bg-slate-800/50 text-white rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent placeholder-gray-500 backdrop-blur-sm"
                />
                <p className="text-xs text-gray-400 mt-2">
                  Get a free key at{' '}
                  <a href="https://openweathermap.org/api" target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:text-blue-300 hover:underline">
                    openweathermap.org/api
                  </a>
                </p>
              </div>
              
              <div>
                <label className="block text-sm font-semibold text-gray-200 mb-3">
                  🔍 SerpAPI Key (for Web Search tool - optional)
                </label>
                <input
                  type="password"
                  value={externalApiKeys.serpapi}
                  onChange={(e) => setExternalApiKeys({...externalApiKeys, serpapi: e.target.value})}
                  placeholder="Enter SerpAPI key (optional)"
                  className="w-full px-5 py-4 border-2 border-purple-500/30 bg-slate-800/50 text-white rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent placeholder-gray-500 backdrop-blur-sm"
                />
                <p className="text-xs text-gray-400 mt-2">
                  Get a key at{' '}
                  <a href="https://serpapi.com" target="_blank" rel="noopener noreferrer" className="text-purple-400 hover:text-purple-300 hover:underline">
                    serpapi.com
                  </a>
                  {' '}(Free tier: 100 searches/month). Falls back to DuckDuckGo if not provided.
                </p>
              </div>
              
              <div className="bg-blue-500/10 border border-blue-500/30 rounded-xl p-4 backdrop-blur-sm">
                <p className="text-sm text-blue-300">
                  <strong>Note:</strong> Calculator tool works without any API key. Web Search will use DuckDuckGo's free API as a fallback if SerpAPI is not configured.
                </p>
              </div>
            </div>
            
            <div className="flex gap-4 mt-8">
              <button
                onClick={() => setShowExternalApiSettings(false)}
                className="flex-1 px-6 py-4 bg-slate-700/50 text-gray-300 rounded-xl hover:bg-slate-600 border border-slate-600 hover:border-slate-500 font-semibold transition-all duration-300"
              >
                Cancel
              </button>
              <button
                onClick={saveExternalApiKeys}
                className="flex-1 px-6 py-4 bg-gradient-to-r from-[#6A8FD4] to-[#5A7FC4] text-white rounded-xl 
             hover:from-[#5A7FC4] hover:to-[#4A6FB4] font-bold shadow-xl 
             hover:shadow-2xl transition-all duration-300 transform hover:scale-105"
              >
                Save API Keys
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }
  
  // Agent List View
  if (view === 'list') {
    return (
      // <div className="min-h-screen bg-[#A9C9F4] flex items-center justify-center p-4">
      <div
  className="min-h-screen flex p-4"
  style={{ background: 'linear-gradient(to right, #4A8FE2,rgb(245, 240, 190))' }}
>
        <div className="max-w-7xl mx-auto p-8">
          {/* Hero Header */}
          <div className="mb-12">
            <div className="flex justify-between items-start mb-6">
            <div>
            <img src="Cognizant Logo.png" alt="Logo" className="logo"/>
  <h1
    className="text-6xl font-black text-transparent bg-clip-text bg-gradient-to-r from-[#1E3A8A] to-[#3B82F6] mb-3"
    style={{ fontFamily: '"Manipulative", Inter, sans-serif' }}
  >
    My AI Agents
  </h1>
  <p className="text-xl text-white-200 font-bold">
    Build, customize, and deploy intelligent AI assistants
  </p>
</div>
              <div className="flex gap-3">
                
                <button
                  onClick={() => setShowExternalApiSettings(true)}
                  className="group relative flex items-center gap-2 px-5 py-3 bg-blue-500 text-white rounded-xl shadow-lg hover:shadow-2xl hover:shadow-blue-500/50 transform hover:scale-105 transition-all duration-300"
                >
                  <Settings size={20} className="group-hover:rotate-90 transition-transform duration-300" />
                  <span className="font-semibold">Tool APIs</span>
                </button>
                <button
                  onClick={() => setShowApiKeyInput(true)}
                  className="group relative flex items-center gap-2 px-5 py-3 bg-gradient-to-r from-slate-700 to-slate-900 text-white rounded-xl shadow-lg hover:shadow-2xl hover:shadow-slate-500/50 transform hover:scale-105 transition-all duration-300 border border-slate-600"
                >
                  <Settings size={20} className="group-hover:rotate-90 transition-transform duration-300" />
                  <span className="font-semibold">Claude API</span>
                </button>
                <button
                  onClick={() => setView('create')}
                  className="group relative flex items-center gap-2 px-5 py-3 bg-blue-500 text-white rounded-xl shadow-lg hover:shadow-2xl hover:shadow-blue-500/50 transform hover:scale-105 transition-all duration-300"
                >
                  <Plus size={24} className="font-bold" />
                  Create Agent
                  <div className="absolute inset-0 rounded-xl bg-white opacity-0 hover:opacity-20 transition-opacity"></div>
                </button>
              </div>
            </div>
            
            {/* Stats Bar */}
            {agents.length > 0 && (
              <div className="flex gap-6 mt-8">
                <div className="group relative flex items-center gap-2 px-5 py-3 bg-[#2F4F9D] text-white rounded-xl shadow-lg hover:shadow-2xl hover:shadow-blue-900/50 transform hover:scale-105 transition-all duration-300">
                  <div className="w-3 h-3 bg-blue-400 rounded-full animate-pulse"></div>
                  <span className="text-blue-200 font-bold">{agents.length} Active Agent{agents.length !== 1 ? 's' : ''}</span>
                </div>
                <div className="group relative flex items-center gap-2 px-5 py-3 bg-[#2F4F9D] text-white rounded-xl shadow-lg hover:shadow-2xl hover:shadow-blue-900/50 transform hover:scale-105 transition-all duration-300">
                  <span className="text-2xl">🤖</span>
                  <span className="text-purple-200 font-semibold">Claude Sonnet 4.5</span>
                </div>
              </div>
            )}
          </div>
          
          {agents.length === 0 ? (
            <div className="text-center py-24 bg-[#1B2A4E] rounded-3xl shadow-2xl border border-[#1B2A4E]/40 backdrop-blur-sm">
              <div className="mb-6">
                <div className="inline-block p-6 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full mb-6 shadow-xl">
                  <Plus size={48} className="text-white" />
                </div>
              </div>
              <h3 className="text-3xl font-bold text-white mb-3">No agents yet</h3>
              <p className="text-gray-400 text-lg mb-8 max-w-md mx-auto">Create your first AI agent to get started with intelligent automation</p>
              <button
                onClick={() => setView('create')}
                
className="px-10 py-4 bg-[#6A8FD4] text-white rounded-xl 
hover:bg-[#5A7FC4] font-bold text-lg shadow-xl 
hover:shadow-2xl transform hover:scale-105 transition-all duration-300"
>

                🚀 Create Your First Agent
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {agents.map((agent, index) => (
                <div 
                  key={agent.id} 
                  className="group agent-card relative bg-gradient-to-br from-slate-800/80 to-slate-900/80 rounded-2xl shadow-2xl p-6 border border-purple-500/20 backdrop-blur-sm hover:border-purple-500/50 transition-all duration-300"
                  style={{ animationDelay: `${index * 0.1}s` }}
                >
                  {/* Gradient Overlay */}
                  <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-blue-500/10 via-purple-500/10 to-pink-500/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  
                  {/* Content */}
                  <div className="relative z-10">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <h3 className="text-2xl font-bold text-white mb-2 group-hover:text-transparent group-hover:bg-clip-text group-hover:bg-gradient-to-r group-hover:from-blue-400 group-hover:to-purple-400 transition-all duration-300">
                          {agent.name}
                        </h3>
                        <div className="w-16 h-1 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full mb-3"></div>
                      </div>
                      <div className="p-3 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-xl border border-blue-500/30">
                        <span className="text-3xl">🤖</span>
                      </div>
                    </div>
                    
                    <p className="text-gray-300 text-sm mb-6 line-clamp-3 leading-relaxed">{agent.systemPrompt}</p>
                    
                    <div className="space-y-2 mb-6">
                      {agent.documents && agent.documents.length > 0 && (
                        <div className="flex items-center gap-2 px-3 py-2 bg-blue-500/20 rounded-lg border border-blue-500/30">
                          <File size={16} className="text-blue-400" />
                          <span className="text-sm text-blue-300 font-medium">{agent.documents.length} document{agent.documents.length !== 1 ? 's' : ''}</span>
                        </div>
                      )}
                      {agent.tools && agent.tools.length > 0 && (
                        <div className="flex items-center gap-2 px-3 py-2 bg-green-500/20 rounded-lg border border-green-500/30">
                          <span className="text-lg">🔧</span>
                          <span className="text-sm text-green-300 font-medium">{agent.tools.length} tool{agent.tools.length !== 1 ? 's' : ''}</span>
                        </div>
                      )}
                    </div>
                    
                    <div className="flex gap-2">
                      <button
                        onClick={() => startChat(agent)}
                        className="flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-gradient-to-r from-green-500 to-emerald-600 text-white rounded-xl shadow-lg hover:shadow-xl hover:shadow-green-500/50 transform hover:scale-105 transition-all duration-300 font-semibold"
                      >
                        <MessageSquare size={18} />
                        Chat
                      </button>
                      <button
                        onClick={() => startEdit(agent)}
                        className="px-4 py-3 bg-slate-700/50 text-gray-300 rounded-xl hover:bg-slate-600 border border-slate-600 hover:border-slate-500 transition-all duration-300"
                      >
                        <Edit size={18} />
                      </button>
                      <button
                        onClick={() => deleteAgent(agent.id)}
                        className="px-4 py-3 bg-red-500/20 text-red-400 rounded-xl hover:bg-red-500/30 border border-red-500/30 hover:border-red-500/50 transition-all duration-300"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    );
  }
  
  // Create/Edit Agent View
  if (view === 'create' || view === 'edit') {
    return (
      <div className="min-h-screen flex items-center justify-center p-4"
      style={{ background: 'linear-gradient(to right, #4A8FE2,rgb(245, 240, 190))' }}
    >
        <div className="w-full max-w-4xl mx-auto">
          {/* Header Card */}
          <div className="relative bg-[#6A8FD4] rounded-2xl p-8 mb-6 text-white overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 via-purple-500/20 to-pink-500/20"></div>
            <div className="relative z-10">
              <h2 className="text-4xl font-bold mb-2">
                {view === 'create' ? '✨ Create New Agent' : '✏️ Edit Agent'}
              </h2>
              <p className="text-blue-100">Configure your AI agent's personality, knowledge, and capabilities</p>
            </div>
          </div>
          
          {/* Main Form Card */}
          <div className="relative bg-gradient-to-br from-slate-800/90 to-slate-900/90 rounded-2xl shadow-2xl p-8 space-y-8 border border-purple-500/20 backdrop-blur-sm">
            <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-blue-500/5 via-purple-500/5 to-pink-500/5"></div>
            <div className="relative z-10 space-y-8">
              {/* Agent Name */}
              <div className="space-y-3">
                <label className="flex items-center gap-2 text-lg font-bold text-white">
                  <span className="text-2xl">🤖</span>
                  Agent Name
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="e.g., Customer Support Assistant"
                  className="w-full px-5 py-3 border-2 border-purple-500/30 bg-slate-800/50 text-white rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition text-lg placeholder-gray-500 backdrop-blur-sm"
                />
              </div>
              
              {/* System Prompt */}
              <div className="space-y-3">
                <label className="flex items-center gap-2 text-lg font-bold text-white">
                  <span className="text-2xl">💭</span>
                  System Prompt (Instructions)
                </label>
                <textarea
                  value={formData.systemPrompt}
                  onChange={(e) => setFormData({ ...formData, systemPrompt: e.target.value })}
                  placeholder="You are a helpful assistant that..."
                  rows={6}
                  className="w-full px-5 py-3 border-2 border-purple-500/30 bg-slate-800/50 text-white rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition text-lg resize-none placeholder-gray-500 backdrop-blur-sm"
                />
              </div>
              
              {/* Knowledge Base */}
              <div className="space-y-3">
                <label className="flex items-center gap-2 text-lg font-bold text-white">
                  <span className="text-2xl">📚</span>
                  Knowledge Base (Upload Documents)
                </label>
                <div className="file-upload-area border-2 border-dashed border-purple-500/30 bg-gradient-to-br from-blue-500/10 to-purple-500/10 rounded-xl p-8 text-center hover:border-purple-500/50 hover:bg-gradient-to-br hover:from-blue-500/20 hover:to-purple-500/20 transition-all cursor-pointer backdrop-blur-sm">
                  <input
                    type="file"
                    id="file-upload"
                    multiple
                    accept=".txt,.md,.csv,.json"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                  <label
                    htmlFor="file-upload"
                    className="cursor-pointer flex flex-col items-center"
                  >
                    <Upload className="w-16 h-16 text-purple-400 mb-3" />
                    <p className="text-purple-300 font-semibold text-lg mb-1">Click to upload documents</p>
                    <p className="text-sm text-purple-400">Supports: .txt, .md, .csv, .json</p>
                  </label>
                </div>
                
                {formData.documents.length > 0 && (
                  <div className="mt-4 space-y-3">
                    {formData.documents.map((doc) => (
                      <div
                        key={doc.id}
                        className="flex items-center justify-between bg-gradient-to-r from-blue-500/20 to-purple-500/20 p-4 rounded-xl border border-blue-500/30 hover:border-blue-500/50 transition backdrop-blur-sm"
                      >
                        <div className="flex items-center gap-3">
                          <div className="bg-blue-500 p-2 rounded-lg">
                            <File className="w-5 h-5 text-white" />
                          </div>
                          <div>
                            <p className="text-sm font-semibold text-white">{doc.name}</p>
                            <p className="text-xs text-gray-400">
                              {(doc.size / 1024).toFixed(1)} KB
                            </p>
                          </div>
                        </div>
                        <button
                          onClick={() => removeDocument(doc.id)}
                          className="p-2 hover:bg-red-500/20 rounded-lg transition group"
                        >
                          <X className="w-5 h-5 text-gray-400 group-hover:text-red-400" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
              
              {/* Tools & Capabilities */}
              <div className="space-y-4">
                <label className="flex items-center gap-2 text-lg font-bold text-white">
                  <span className="text-2xl">🛠️</span>
                  Tools & Capabilities
                </label>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {availableTools.map((tool) => (
                    <div
                      key={tool.id}
                      onClick={() => toggleTool(tool.id)}
                      className={`p-5 border-2 rounded-xl cursor-pointer transition-all transform hover:scale-105 backdrop-blur-sm ${
                        (formData.tools || []).includes(tool.id)
                          ? 'border-purple-500 bg-gradient-to-br from-purple-500/20 to-pink-500/20 shadow-lg shadow-purple-500/20'
                          : 'border-slate-600/50 bg-slate-800/30 hover:border-slate-500 hover:shadow-md'
                      }`}
                    >
                      <div className="flex items-center gap-3 mb-2">
                        <span className="text-3xl">{tool.icon}</span>
                        <span className="font-bold text-white">{tool.name}</span>
                      </div>
                      <p className="text-xs text-gray-400 leading-relaxed">{tool.description}</p>
                      {(formData.tools || []).includes(tool.id) && (
                        <div className="mt-3 flex items-center gap-1 text-purple-400 text-sm font-semibold">
                          <span>✓</span>
                          <span>Enabled</span>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
              
              {/* Advanced Settings */}
              <div className="bg-gradient-to-r from-purple-500/10 to-pink-500/10 rounded-xl p-6 space-y-5 border border-purple-500/20 backdrop-blur-sm">
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <span className="text-2xl">⚙️</span>
                  Advanced Settings
                </h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Temperature */}
                  <div className="space-y-3">
                    <label className="block text-sm font-bold text-gray-300">
                      Temperature: <span className="text-purple-400">{formData.temperature}</span>
                    </label>
                    <input
                      type="range"
                      min="0"
                      max="1"
                      step="0.1"
                      value={formData.temperature}
                      onChange={(e) => setFormData({ ...formData, temperature: parseFloat(e.target.value) })}
                      className="w-full h-3 bg-gradient-to-r from-blue-200 to-purple-300 rounded-lg appearance-none cursor-pointer"
                      style={{
                        background: `linear-gradient(to right, #3b82f6 0%, #8b5cf6 ${formData.temperature * 100}%, #6b7280 ${formData.temperature * 100}%, #6b7280 100%)`
                      }}
                    />
                    <div className="flex justify-between text-xs text-gray-400">
                      <span>🎯 Focused</span>
                      <span>🎨 Creative</span>
                    </div>
                  </div>
                  
                  {/* Max Tokens */}
                  <div className="space-y-3">
                    <label className="block text-sm font-bold text-gray-300">
                      Max Tokens
                    </label>
                    <input
                      type="number"
                      value={formData.maxTokens}
                      onChange={(e) => setFormData({ ...formData, maxTokens: parseInt(e.target.value) })}
                      className="w-full px-4 py-3 border-2 border-purple-500/30 bg-slate-800/50 text-white rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent transition backdrop-blur-sm"
                    />
                    <p className="text-xs text-gray-400">Controls response length</p>
                  </div>
                </div>
              </div>
              
              {/* Action Buttons */}
              <div className="flex gap-4 pt-4">
                <button
                  onClick={() => setView('list')}
                  className="flex-1 px-8 py-4 bg-slate-700/50 text-gray-300 rounded-xl hover:bg-slate-600 font-semibold text-lg transition border border-slate-600 hover:border-slate-500 transform hover:scale-105"
                >
                  Cancel
                </button>
                <button
                  onClick={view === 'create' ? createAgent : updateAgent}
                  disabled={!formData.name || !formData.systemPrompt}
                  className="flex-1 px-8 py-4 bg-[#6A8FD4] text-white rounded-xl 
             hover:bg-[#5A7FC4] disabled:bg-[#6A8FD4] font-bold text-lg 
             shadow-xl hover:shadow-2xl transition-all transform 
             hover:scale-105 disabled:transform-none disabled:cursor-not-allowed">
                
                  {view === 'create' ? '🚀 Create Agent' : '💾 Save Changes'}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
  
  // Chat View
  if (view === 'chat') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-300 to-slate-900 flex flex-col">
        <div className="bg-gradient-to-r from-slate-800/90 to-slate-900/90 shadow-2xl p-6 border-b border-purple-500/20 backdrop-blur-sm">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl">
                <MessageSquare size={24} className="text-white" />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-white">{selectedAgent.name}</h2>
                <p className="text-sm text-gray-400">Powered by Claude Sonnet 4.5</p>
              </div>
            </div>
            <button
              onClick={() => setView('list')}
              className="px-6 py-3 bg-slate-700/50 text-gray-300 rounded-xl hover:bg-slate-600 border border-slate-600 hover:border-slate-500 font-semibold transition-all"
            >
              ← Back to Agents
            </button>
          </div>
          {(selectedAgent.documents && selectedAgent.documents.length > 0) || (selectedAgent.tools && selectedAgent.tools.length > 0) ? (
            <div className="flex flex-wrap items-center gap-3 text-sm mt-4 pt-4 border-t border-slate-700">
              {selectedAgent.documents && selectedAgent.documents.length > 0 && (
                <div className="flex items-center gap-2 px-4 py-2 bg-blue-500/20 rounded-lg border border-blue-500/30">
                  <File size={16} className="text-blue-400" />
                  <span className="text-blue-300 font-medium">{selectedAgent.documents.map(d => d.name).join(', ')}</span>
                </div>
              )}
              {selectedAgent.tools && selectedAgent.tools.length > 0 && (
                <div className="flex items-center gap-2 px-4 py-2 bg-green-500/20 rounded-lg border border-green-500/30">
                  <span className="text-lg">🔧</span>
                  <span className="text-green-300 font-medium">Tools: {selectedAgent.tools.join(', ')}</span>
                </div>
              )}
            </div>
          ) : null}
        </div>
        
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {messages.length === 0 && (
            <div className="text-center text-[#1B2A4E] mt-12">
              <div className="inline-block p-6 bg-[#3C66CE] rounded-2xl mb-4 border border-[#3C66CE]/40">
                <MessageSquare size={48} className="mx-auto opacity-80 text-[#1B2A4E]" />
              </div>
              <p className="text-lg font-semibold text-[#1B2A4E]">Start a conversation with your agent</p>
            </div>
          )}
          
          {messages.map((msg, idx) => (
            <div
              key={idx}
              className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`message-bubble max-w-2xl px-6 py-4 rounded-2xl ${
                  msg.isToolUse
                    ? 'bg-gradient-to-r from-yellow-500/20 to-amber-500/20 text-yellow-300 border border-yellow-500/30 backdrop-blur-sm'
                    : msg.role === 'user'
                    ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-xl'
                    : 'bg-gradient-to-br from-slate-800/80 to-slate-900/80 text-gray-200 shadow-xl border border-purple-500/20 backdrop-blur-sm'
                }`}
              >
                {msg.content}
              </div>
            </div>
          ))}
          
          {isLoading && (
            <div className="flex justify-start">
              <div className="bg-gradient-to-br from-slate-800/80 to-slate-900/80 px-6 py-4 rounded-2xl shadow-xl border border-purple-500/20 backdrop-blur-sm">
                <div className="flex gap-2">
                  <div className="w-3 h-3 bg-purple-400 rounded-full animate-bounce"></div>
                  <div className="w-3 h-3 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                  <div className="w-3 h-3 bg-pink-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                </div>
              </div>
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </div>
        
        <div className="bg-gradient-to-r from-slate-800/90 to-slate-900/90 shadow-2xl p-6 border-t border-purple-500/20 backdrop-blur-sm">
          <div className="max-w-4xl mx-auto flex gap-3">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && !isLoading && sendMessage()}
              placeholder="Type your message..."
              className="flex-1 px-6 py-4 border-2 border-purple-500/30 bg-slate-800/50 text-white rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent placeholder-gray-500 text-lg backdrop-blur-sm"
              disabled={isLoading}
            />
            <button
              onClick={sendMessage}
              disabled={!input.trim() || isLoading}
              className="px-8 py-4 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-xl hover:from-blue-600 hover:to-purple-700 disabled:from-gray-600 disabled:to-gray-700 font-bold shadow-xl hover:shadow-2xl transition-all transform hover:scale-105 disabled:transform-none"
            >
              <Send size={24} />
            </button>
          </div>
        </div>
      </div>
    );
  }
}
